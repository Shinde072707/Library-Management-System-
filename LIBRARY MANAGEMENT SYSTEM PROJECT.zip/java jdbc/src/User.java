import java.sql.*;
import java.util.Scanner;

public class User {
    static Scanner sc = new Scanner(System.in);

    public static void register() {
        System.out.print("Enter name: ");
        String name = sc.next();
        System.out.print("Enter email: ");
        String email = sc.next();
        System.out.print("Enter password: ");
        String password = sc.next();

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users(name, email, password) VALUES (?, ?, ?)");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.executeUpdate();
            System.out.println("User registered!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void login() {
        System.out.print("Email: ");
        String email = sc.next();
        System.out.print("Password: ");
        String password = sc.next();

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE email=? AND password=?");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("user_id");
                userMenu(userId);
            } else {
                System.out.println("Invalid login!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void userMenu(int userId) {
        while (true) {
            System.out.println("\n--- User Panel ---");
            System.out.println("1. View All Books");
            System.out.println("2. Issue Book");
            System.out.println("3. Return Book");
            System.out.println("0. Logout");
            System.out.print("Choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1 -> Book.viewBooks();
                case 2 -> IssueReturn.issueBook(userId);
                case 3 -> IssueReturn.returnBook(userId);
                case 0 -> {
                    System.out.println("Logging out...");
                    return;
                }
                default -> System.out.println("Invalid!");
            }
        }
    }
}
