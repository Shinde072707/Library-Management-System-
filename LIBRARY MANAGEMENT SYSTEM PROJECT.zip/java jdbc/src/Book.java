import java.sql.*;
import java.util.Scanner;

public class Book {
    static Scanner sc = new Scanner(System.in);

    public static void addBook() {
        System.out.print("Book title: ");
        String title = sc.next();
        System.out.print("Author: ");
        String author = sc.next();
        System.out.print("Quantity: ");
        int quantity = sc.nextInt();

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO books(title, author, quantity) VALUES (?, ?, ?)");
            ps.setString(1, title);
            ps.setString(2, author);
            ps.setInt(3, quantity);
            ps.executeUpdate();
            System.out.println("Book added.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewBooks() {
        try (Connection conn = DBConnection.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM books");
            System.out.println("\n--- Book List ---");
            while (rs.next()) {
                System.out.printf("ID: %d, Title: %s, Author: %s, Qty: %d%n",
                        rs.getInt("book_id"), rs.getString("title"), rs.getString("author"), rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteBook() {
        System.out.print("Enter Book ID to delete: ");
        int id = sc.nextInt();

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM books WHERE book_id=?");
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows > 0) System.out.println("Book deleted.");
            else System.out.println("Book not found.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
