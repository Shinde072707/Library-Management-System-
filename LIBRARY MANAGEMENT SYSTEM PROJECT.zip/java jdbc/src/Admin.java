import java.sql.*;
import java.util.Scanner;

public class Admin {
    static Scanner sc = new Scanner(System.in);

    public static void login() {
        System.out.print("Username: ");
        String username = sc.next();
        System.out.print("Password: ");
        String password = sc.next();

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM admin WHERE username=? AND password=?");
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                adminMenu();
            } else {
                System.out.println("Invalid admin credentials!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void adminMenu() {
        while (true) {
            System.out.println("\n--- Admin Panel ---");
            System.out.println("1. Add Book");
            System.out.println("2. View All Books");
            System.out.println("3. Delete Book");
            System.out.println("4. View Issued Books");
            System.out.println("0. Logout");
            System.out.print("Choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1 -> Book.addBook();
                case 2 -> Book.viewBooks();
                case 3 -> Book.deleteBook();
                case 4 -> IssueReturn.viewIssuedBooks();
                case 0 -> {
                    System.out.println("Logging out...");
                    return;
                }
                default -> System.out.println("Invalid!");
            }
        }
    }
}
