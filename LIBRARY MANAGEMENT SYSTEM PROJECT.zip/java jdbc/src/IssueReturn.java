import java.sql.*;
import java.time.LocalDate;
import java.util.Scanner;

public class IssueReturn {
    static Scanner sc = new Scanner(System.in);

    public static void issueBook(int userId) {
        System.out.print("Enter Book ID: ");
        int bookId = sc.nextInt();

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement checkBook = conn.prepareStatement("SELECT quantity FROM books WHERE book_id=?");
            checkBook.setInt(1, bookId);
            ResultSet rs = checkBook.executeQuery();

            if (rs.next() && rs.getInt("quantity") > 0) {
                PreparedStatement issue = conn.prepareStatement(
                        "INSERT INTO issued_books(book_id, user_id, issue_date) VALUES (?, ?, ?)");
                issue.setInt(1, bookId);
                issue.setInt(2, userId);
                issue.setDate(3, Date.valueOf(LocalDate.now()));
                issue.executeUpdate();

                conn.prepareStatement("UPDATE books SET quantity = quantity - 1 WHERE book_id = " + bookId).executeUpdate();
                System.out.println("Book issued.");
            } else {
                System.out.println("Book not available.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void returnBook(int userId) {
        System.out.print("Enter Book ID: ");
        int bookId = sc.nextInt();

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE issued_books SET return_date=? WHERE book_id=? AND user_id=? AND return_date IS NULL");
            ps.setDate(1, Date.valueOf(LocalDate.now()));
            ps.setInt(2, bookId);
            ps.setInt(3, userId);
            int updated = ps.executeUpdate();

            if (updated > 0) {
                conn.prepareStatement("UPDATE books SET quantity = quantity + 1 WHERE book_id = " + bookId).executeUpdate();
                System.out.println("Book returned.");
            } else {
                System.out.println("No such issued book found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewIssuedBooks() {
        try (Connection conn = DBConnection.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT ib.issue_id, u.name, b.title, ib.issue_date, ib.return_date " +
                    "FROM issued_books ib JOIN users u ON ib.user_id = u.user_id " +
                    "JOIN books b ON ib.book_id = b.book_id");

            while (rs.next()) {
                System.out.printf("IssueID: %d, User: %s, Book: %s, Issued: %s, Returned: %s%n",
                        rs.getInt("issue_id"), rs.getString("name"), rs.getString("title"),
                        rs.getDate("issue_date"), rs.getDate("return_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
